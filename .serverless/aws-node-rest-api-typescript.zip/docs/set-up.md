# Set Up
TODO

## Install locally
* `bundle install`
* `touch .env`
* Add secrets to .env
