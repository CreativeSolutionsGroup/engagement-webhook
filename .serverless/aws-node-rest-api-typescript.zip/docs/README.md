# Engagement Webhook Documentation

## Table of Contents
- [Architecture](https://github.com/CreativeSolutionsGroup/engagement-webhook/blob/master/docs/architecture.md)
- [Contributing](https://github.com/CreativeSolutionsGroup/engagement-webhook/blob/master/docs/contributing.md)
- [Deployment](https://github.com/CreativeSolutionsGroup/engagement-webhook/blob/master/docs/deployment.md)
- [Set Up](https://github.com/CreativeSolutionsGroup/engagement-webhook/blob/master/docs/set-up.md)