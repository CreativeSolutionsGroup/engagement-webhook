# Lambda

Everything runs cheaper on lambda.

`yarn global add serverless`

`serverless deploy`